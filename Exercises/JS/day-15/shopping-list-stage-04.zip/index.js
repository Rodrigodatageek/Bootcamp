'use strict';

const items = [
  {
    name: 'bananas',
    amount: '1kg',
  },
  {
    name: 'apples',
    amount: 5,
  },
  {
    name: 'tomatos',
    amount: 10,
  },
  {
    name: 'butter',
    amount: '250g',
  },
];

const renderItems = () => {
  const listElm = document.querySelector('#list');
  listElm.innerHTML = '';
  items.forEach((item) => {
    listElm.innerHTML += `
      <div class="item">
        <span>${item.name}, ${item.amount}</span>
        <button class="btn-remove">remove</button>
      </div>
    `;
  });

  const removeButtons = document.querySelectorAll('.btn-remove');
  removeButtons.forEach((btn, index) => {
    btn.addEventListener('click', () => {
      items.splice(index, 1);
      renderItems();
    });
  });
};

const btnAdd = document.querySelector('#btn-add');
btnAdd.addEventListener('click', (e) => {
  const itemName = document.querySelector('#name-input').value;
  const itemAmount = document.querySelector('#amount-input').value;
  items.push(
    { 
      name: itemName,
      amount: itemAmount,
    }
  );
  renderItems();
  e.preventDefault();
});

renderItems();